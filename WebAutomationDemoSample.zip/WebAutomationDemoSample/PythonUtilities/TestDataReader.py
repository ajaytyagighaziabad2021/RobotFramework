

def read_data_from_file(key):
    file=open('../TestData/RegistrationTestData.txt')
    data=file.readline()
    while(data):
        if(data.__contains__(key)):
            return data.split("=")[1]

